服务器执行命令：
env VSOMEIP_CONFIGURATION=vsomeip-server.json VSOMEIP_APPLICATION_NAME=Server ./response-video-sample ./server_files/sample.mp4
客服端执行命令：
env VSOMEIP_CONFIGURATION=vsomeip-client.json  ./request-video-sample ./client_files/recv_sample.mp4 2 Client


